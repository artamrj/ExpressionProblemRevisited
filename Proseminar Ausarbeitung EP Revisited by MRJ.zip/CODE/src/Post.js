"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CombinedPost = exports.TextPost = void 0;
class TextPost {
    constructor(content) {
        this.content = content;
    }
    display() {
        console.log("\x1b[32m%s\x1b[0m", `POST: ${this.content}`);
    }
}
exports.TextPost = TextPost;
class CombinedPost {
    constructor(post1, post2) {
        this.post1 = post1;
        this.post2 = post2;
    }
    display() {
        console.log("\x1b[31m%s\x1b[0m", "COMBINED:");
        this.post1.display();
        this.post2.display();
    }
}
exports.CombinedPost = CombinedPost;
