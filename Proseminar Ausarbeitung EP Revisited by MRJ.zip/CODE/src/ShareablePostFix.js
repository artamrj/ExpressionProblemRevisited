"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShareableCombinedPostFix = exports.ShareableTextPostFix = void 0;
const Shareable_1 = require("./Shareable");
class ShareableTextPostFix extends Shareable_1.ShareableTextPost {
    constructor(content) {
        super(content);
    }
}
exports.ShareableTextPostFix = ShareableTextPostFix;
class ShareableCombinedPostFix extends Shareable_1.ShareableCombinedPost {
    constructor(post1, post2) {
        super(post1, post2);
    }
}
exports.ShareableCombinedPostFix = ShareableCombinedPostFix;
