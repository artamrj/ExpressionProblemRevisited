"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShareableCombinedPost = exports.ShareableTextPost = void 0;
const Post_1 = require("./Post");
class ShareableTextPost extends Post_1.TextPost {
    share() {
        console.log("\x1b[34m%s\x1b[0m", "SHARED POST: " + this.content);
    }
}
exports.ShareableTextPost = ShareableTextPost;
class ShareableCombinedPost extends Post_1.CombinedPost {
    share() {
        console.log("\x1b[35m%s\x1b[0m", "SHARED COMBINED:");
        this.post1.share();
        this.post2.share();
    }
}
exports.ShareableCombinedPost = ShareableCombinedPost;
